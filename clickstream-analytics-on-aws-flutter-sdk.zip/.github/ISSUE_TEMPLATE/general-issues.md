---
name: "\U00002753 General Issue"
about: Create a new issue
title: ""
labels: needs-triage, guidance
---

## :question: General Issue

### The Question
<!--
Ask your question here. Include any details relevant. Make sure you are not falling prey to the [X/Y problem][2]!

[2]: http://xyproblem.info
-->

### Other information
<!-- e.g. detailed explanation, stacktraces, related issues, suggestions on how to fix, links for us to have context, eg. associated pull-request, stackoverflow, gitter, etc -->