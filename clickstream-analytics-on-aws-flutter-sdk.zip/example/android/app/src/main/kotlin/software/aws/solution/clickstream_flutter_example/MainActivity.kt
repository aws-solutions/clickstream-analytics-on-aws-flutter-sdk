package software.aws.solution.clickstream_flutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
